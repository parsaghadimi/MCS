syms x1 x2 x3

res = [ 10 - x2 - 2* x1 == 0,
        log(x2 - x3) - 0.02 * x3 - 0.1 * x3 ^3 == 0,
        x1 - log(x2 - x3) == 0];

xs = [x1 x2 x3];

pointstar = vpasolve(res, xs)