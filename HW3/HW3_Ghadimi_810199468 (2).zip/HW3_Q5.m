% describe system
func = @(t, x) [-2*x(1) + x(2) + 8*(x(1)^2 + x(2)^2)*sin(2*t);
                -2*x(2) - x(1) + 8*(x(1)^2 + x(2)^2)*cos(2*t)];

ts = 0:0.001:40;

% initial points
x_0 = [1/6, 0; 1/4, 1/10; 1/10, 1/4]';

numInitialConditions = size(x_0, 2);

% caculate and plot Transient Response for Given Initial Points
for i = 1:numInitialConditions
    [t, X] = ode45(func, ts, x_0(:, i));
    
    figure;

    % x_1
    subplot(2, 1, 1);
    plot(t, X(:, 1), 'r', 'LineWidth', 1.5);
    xlabel('Time');
    ylabel('x_1');
    title(sprintf('Transient Response for Initial Condition #%d', i));
    
    % x_2
    subplot(2, 1, 2);
    plot(t, X(:, 2), 'b', 'LineWidth', 1.5);
    xlabel('Time');
    ylabel('x_2');
end
